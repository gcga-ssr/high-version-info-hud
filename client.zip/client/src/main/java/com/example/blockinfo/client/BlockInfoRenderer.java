package com.example.blockinfo.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.RenderType;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class BlockInfoRenderer {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final int PADDING = 8;
    private static final int LINE_HEIGHT = 12;
    private static final int BAR_HEIGHT = 14;
    private static final int BAR_WIDTH = 28;
    private static final float SMOOTHING_FACTOR = 0.15f;

    private static final ResourceLocation FURNACE_GUI = ResourceLocation.fromNamespaceAndPath("minecraft", "textures/gui/container/furnace.png");
    
    private static float currentBoxWidth = 0f;
    private static float currentBoxHeight = 0f;

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        BlockInfoData data = BlockInfoTracker.getCurrentData();
        if (data == null || data.blockName.isEmpty()) return;

        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;
        GuiGraphics gui = event.getGuiGraphics();

        if (data.isFurnace) {
            float cookProgress = 0f;
            if (data.furnaceTotalCookTime > 0) {
                cookProgress = (float) data.furnaceCookTime / data.furnaceTotalCookTime;
                cookProgress = Math.min(Math.max(cookProgress, 0f), 1f);
            }
            
            float burnProgress = 0f;
            if (data.furnaceTotalBurnTime > 0) {
                burnProgress = (float) data.furnaceBurnTime / data.furnaceTotalBurnTime;
                burnProgress = Math.min(Math.max(burnProgress, 0f), 1f);
            }
            
            data.cookProgress = cookProgress;
            data.burnProgress = burnProgress;
        }

        List<String> lines = new ArrayList<>();
        lines.add(data.blockName);
        lines.add("[" + data.modId + "]");

        List<String> extraLines = new ArrayList<>();

        if (data.isFurnace) {
            if (!data.inputItemName.isEmpty()) {
                extraLines.add("输入: " + data.inputItemName + " x" + data.inputItemCount);
            }
            if (!data.fuelItemName.isEmpty()) {
                extraLines.add("燃料: " + data.fuelItemName + " x" + data.fuelItemCount);
            }
            if (!data.outputItemName.isEmpty()) {
                extraLines.add("输出: " + data.outputItemName + " x" + data.outputItemCount);
            }
        }

        if (data.isContainer && data.containerItems != null && !data.containerItems.isEmpty()) {
            extraLines.add("内容:");
        }

        int itemsPerColumn = 5;
        int containerNumColumns = 1;
        int containerColumnWidth = 0;
        int containerMaxRows = 0;
        
        if (data.isContainer && data.containerItems != null && !data.containerItems.isEmpty()) {
            int numItems = data.containerItems.size();
            if (numItems > 15) itemsPerColumn = 8;
            else if (numItems > 10) itemsPerColumn = 6;
            containerNumColumns = (numItems + itemsPerColumn - 1) / itemsPerColumn;
            for (String item : data.containerItems) {
                int w = font.width("  - " + item);
                if (w > containerColumnWidth) containerColumnWidth = w;
            }
            containerMaxRows = Math.min(itemsPerColumn, numItems);
        }

        int maxLineWidth = 0;
        for (String line : lines) {
            int w = font.width(line);
            if (w > maxLineWidth) maxLineWidth = w;
        }
        
        String mineIcon = data.canMine ? "\u2713" : "\u2717";
        int mineIconWidth = font.width(mineIcon);
        maxLineWidth += mineIconWidth + 8;
        for (String line : extraLines) {
            int w = font.width(line);
            if (w > maxLineWidth) maxLineWidth = w;
        }

        if (data.isPlant || data.isFurnace || data.mineProgress > 0f) {
            maxLineWidth += BAR_WIDTH + 12;
        }

        int containerWidth = containerNumColumns * (containerColumnWidth + 10);
        if (containerWidth > maxLineWidth) {
            maxLineWidth = containerWidth;
        }

        int totalLines = lines.size() + extraLines.size();
        int boxHeight = totalLines * LINE_HEIGHT + PADDING * 2;
        if (data.isPlant) boxHeight += BAR_HEIGHT + 6;
        if (data.isFurnace) boxHeight += BAR_HEIGHT * 2 + 6;
        if (data.mineProgress > 0f) boxHeight += BAR_HEIGHT + 6;
        if (data.isContainer && data.containerItems != null && !data.containerItems.isEmpty()) {
            boxHeight += containerMaxRows * LINE_HEIGHT;
        }

        int targetBoxWidth = maxLineWidth + PADDING * 2;

        int screenWidth = mc.getWindow().getGuiScaledWidth();
        
        currentBoxWidth += (targetBoxWidth - currentBoxWidth) * SMOOTHING_FACTOR;
        currentBoxHeight += (boxHeight - currentBoxHeight) * SMOOTHING_FACTOR;
        
        int x = (screenWidth - (int) currentBoxWidth) / 2;
        int y = PADDING;

        RenderSystem.enableBlend();
        gui.fill(x, y, x + (int) currentBoxWidth, y + (int) currentBoxHeight, (int)(0x80000000));
        gui.fill(x + 1, y + 1, x + (int) currentBoxWidth - 1, y + (int) currentBoxHeight - 1, (int)(0x60000000));
        RenderSystem.disableBlend();

        int currentY = y + PADDING;

        int mineColor = data.canMine ? 0x55FF55 : 0xFF5555;
        
        gui.drawString(font, data.blockName, x + PADDING, currentY, 0xFFFFFF);
        currentY += LINE_HEIGHT;
        
        int modIdWidth = font.width("[" + data.modId + "]");
        gui.drawString(font, "[" + data.modId + "]", x + PADDING, currentY, 0xFFFFFF);
        gui.drawString(font, mineIcon, x + PADDING + modIdWidth + 8, currentY, mineColor);
        currentY += LINE_HEIGHT;

        if (data.isPlant) {
            currentY += 2;
            drawArrowBackground(gui, x + PADDING, currentY);
            drawFurnaceArrow(gui, x + PADDING, currentY, data.plantGrowth);
            gui.drawString(font, BlockInfoUtil.formatPercentage(data.plantGrowth), x + PADDING + BAR_WIDTH + 8, currentY + 1, 0xFFFFFF);
            currentY += BAR_HEIGHT + 4;
        }

        if (data.isFurnace) {
            currentY += 2;
            
            gui.drawString(font, "烧制:", x + PADDING, currentY, 0xFFD700);
            drawArrowBackground(gui, x + PADDING + font.width("烧制: ") + 6, currentY);
            drawFurnaceArrow(gui, x + PADDING + font.width("烧制: ") + 6, currentY, data.cookProgress);
            gui.drawString(font, BlockInfoUtil.formatPercentage(data.cookProgress), x + PADDING + font.width("烧制: ") + 6 + BAR_WIDTH + 8, currentY + 1, 0xFFD700);
            currentY += BAR_HEIGHT + 2;
            
            gui.drawString(font, "燃烧:", x + PADDING, currentY, 0xFF6600);
            drawArrowBackground(gui, x + PADDING + font.width("燃烧: ") + 6, currentY);
            drawFurnaceArrow(gui, x + PADDING + font.width("燃烧: ") + 6, currentY, data.burnProgress);
            gui.drawString(font, BlockInfoUtil.formatPercentage(data.burnProgress), x + PADDING + font.width("燃烧: ") + 6 + BAR_WIDTH + 8, currentY + 1, 0xFF6600);
            currentY += BAR_HEIGHT + 4;
        }
        
        if (data.mineProgress > 0f) {
            currentY += 2;
            gui.drawString(font, "挖掘:", x + PADDING, currentY, 0x55FFFF);
            drawArrowBackground(gui, x + PADDING + font.width("挖掘: ") + 6, currentY);
            drawFurnaceArrow(gui, x + PADDING + font.width("挖掘: ") + 6, currentY, data.mineProgress);
            gui.drawString(font, BlockInfoUtil.formatPercentage(data.mineProgress), x + PADDING + font.width("挖掘: ") + 6 + BAR_WIDTH + 8, currentY + 1, 0x55FFFF);
            currentY += BAR_HEIGHT + 4;
        }

        for (String line : extraLines) {
            gui.drawString(font, line, x + PADDING, currentY, 0xFFFFFF);
            currentY += LINE_HEIGHT;
        }
        
        if (data.isContainer && data.containerItems != null && !data.containerItems.isEmpty()) {
            int numItems = data.containerItems.size();
            
            int startX = x + PADDING;
            int startY = currentY;
            
            for (int col = 0; col < containerNumColumns; col++) {
                int colX = startX + col * (containerColumnWidth + 10);
                int colY = startY;
                
                for (int row = 0; row < itemsPerColumn; row++) {
                    int index = col * itemsPerColumn + row;
                    if (index >= numItems) break;
                    
                    gui.drawString(font, "  - " + data.containerItems.get(index), colX, colY, 0xFFFFFF);
                    colY += LINE_HEIGHT;
                }
            }
        }
    }

    private static void drawArrowBackground(GuiGraphics gui, int x, int y) {
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, FURNACE_GUI);
        gui.blit(RenderType::guiTextured, FURNACE_GUI, x, y, 0, 176, 14, BAR_WIDTH, 14, 256, 256);
    }

    private static void drawFurnaceArrow(GuiGraphics gui, int x, int y, float progress) {
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, FURNACE_GUI);
        
        int arrowWidth = (int) (28 * Math.min(progress, 1.0F));
        if (arrowWidth > 0) {
            gui.blit(RenderType::guiTextured, FURNACE_GUI, x, y, 0, 176, 14, arrowWidth, 14, 256, 256);
        }
    }
}
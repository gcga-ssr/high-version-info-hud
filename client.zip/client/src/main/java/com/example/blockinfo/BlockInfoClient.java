package com.example.blockinfo;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import java.util.ArrayList;
import java.util.List;

@Mod(BlockInfoClient.MOD_ID)
public class BlockInfoClient {
    public static final String MOD_ID = "blockinfo";
    public static final Logger LOGGER = LogUtils.getLogger();
    
    public BlockInfoClient(IEventBus modEventBus) {
        modEventBus.addListener(this::registerPayloadHandlers);
        NeoForge.EVENT_BUS.register(com.example.blockinfo.client.BlockInfoTracker.class);
        NeoForge.EVENT_BUS.register(com.example.blockinfo.client.BlockInfoRenderer.class);
    }
    
    private void registerPayloadHandlers(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(
            FurnaceDataPacket.TYPE,
            FurnaceDataPacket.STREAM_CODEC,
            FurnaceDataPacket::handle
        );
        registrar.playToClient(
            ContainerDataPacket.TYPE,
            ContainerDataPacket.STREAM_CODEC,
            ContainerDataPacket::handle
        );
    }
    
    public static class FurnaceDataPacket implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<FurnaceDataPacket> TYPE = 
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(MOD_ID, "furnace_data"));
        
        public static final StreamCodec<FriendlyByteBuf, FurnaceDataPacket> STREAM_CODEC = StreamCodec.of(
            (buf, packet) -> {
                buf.writeBlockPos(packet.pos);
                buf.writeInt(packet.cookTime);
                buf.writeInt(packet.cookTotal);
                buf.writeInt(packet.burnTime);
                buf.writeInt(packet.burnTotal);
                buf.writeInt(packet.inputCount);
                buf.writeUtf(packet.inputName);
                buf.writeInt(packet.fuelCount);
                buf.writeUtf(packet.fuelName);
                buf.writeInt(packet.outputCount);
                buf.writeUtf(packet.outputName);
            },
            (buf) -> new FurnaceDataPacket(
                buf.readBlockPos(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readUtf(),
                buf.readInt(),
                buf.readUtf(),
                buf.readInt(),
                buf.readUtf()
            )
        );
        
        public final BlockPos pos;
        public final int cookTime;
        public final int cookTotal;
        public final int burnTime;
        public final int burnTotal;
        public final int inputCount;
        public final String inputName;
        public final int fuelCount;
        public final String fuelName;
        public final int outputCount;
        public final String outputName;
        
        public FurnaceDataPacket(BlockPos pos, int cookTime, int cookTotal, int burnTime, int burnTotal,
                                  int inputCount, String inputName, int fuelCount, String fuelName,
                                  int outputCount, String outputName) {
            this.pos = pos;
            this.cookTime = cookTime;
            this.cookTotal = cookTotal;
            this.burnTime = burnTime;
            this.burnTotal = burnTotal;
            this.inputCount = inputCount;
            this.inputName = inputName;
            this.fuelCount = fuelCount;
            this.fuelName = fuelName;
            this.outputCount = outputCount;
            this.outputName = outputName;
        }
        
        @Override
        public CustomPacketPayload.Type<FurnaceDataPacket> type() {
            return TYPE;
        }
        
        public void handle(net.neoforged.neoforge.network.handling.IPayloadContext context) {
            context.enqueueWork(() -> {
                com.example.blockinfo.client.ClientFurnaceCache.updateData(
                    pos, cookTime, cookTotal, burnTime, burnTotal,
                    inputCount, inputName, fuelCount, fuelName, outputCount, outputName
                );
            });
        }
    }
    
    public static class ContainerDataPacket implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<ContainerDataPacket> TYPE = 
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(MOD_ID, "container_data"));
        
        public static final StreamCodec<FriendlyByteBuf, ContainerDataPacket> STREAM_CODEC = StreamCodec.of(
            (buf, packet) -> {
                buf.writeBlockPos(packet.pos);
                buf.writeInt(packet.itemNames.size());
                for (int i = 0; i < packet.itemNames.size(); i++) {
                    buf.writeUtf(packet.itemNames.get(i));
                    buf.writeInt(packet.itemCounts.get(i));
                }
            },
            (buf) -> {
                BlockPos pos = buf.readBlockPos();
                int count = buf.readInt();
                List<String> itemNames = new ArrayList<>();
                List<Integer> itemCounts = new ArrayList<>();
                for (int i = 0; i < count; i++) {
                    itemNames.add(buf.readUtf());
                    itemCounts.add(buf.readInt());
                }
                return new ContainerDataPacket(pos, itemNames, itemCounts);
            }
        );
        
        public final BlockPos pos;
        public final List<String> itemNames;
        public final List<Integer> itemCounts;
        
        public ContainerDataPacket(BlockPos pos, List<String> itemNames, List<Integer> itemCounts) {
            this.pos = pos;
            this.itemNames = itemNames;
            this.itemCounts = itemCounts;
        }
        
        @Override
        public CustomPacketPayload.Type<ContainerDataPacket> type() {
            return TYPE;
        }
        
        public void handle(net.neoforged.neoforge.network.handling.IPayloadContext context) {
            context.enqueueWork(() -> {
                com.example.blockinfo.client.ClientContainerCache.updateData(pos, itemNames, itemCounts);
            });
        }
    }
}
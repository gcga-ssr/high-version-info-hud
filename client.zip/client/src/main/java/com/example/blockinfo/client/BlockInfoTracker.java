package com.example.blockinfo.client;

import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import java.lang.reflect.Field;

public class BlockInfoTracker {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static BlockInfoData currentData = new BlockInfoData();
    private static BlockPos lastPos = BlockPos.ZERO;
    private static int tickCounter = 0;
    private static final int UPDATE_INTERVAL = 2;
    private static final Map<String, String> itemNameCache = new HashMap<>();
    private static Field destroyProgressField = null;
    
    static {
        try {
            Class<?> clazz = Class.forName("net.minecraft.client.multiplayer.ClientLevel$DestroyProgress");
            for (Field f : clazz.getDeclaredFields()) {
                if (f.getType() == int.class) {
                    destroyProgressField = f;
                    destroyProgressField.setAccessible(true);
                    break;
                }
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to initialize destroy progress field", e);
        }
    }
    
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            currentData.clear();
            return;
        }
        
        HitResult hitResult = mc.hitResult;
        if (hitResult != null && hitResult.getType() == HitResult.Type.BLOCK) {
            BlockHitResult blockHit = (BlockHitResult) hitResult;
            BlockPos pos = blockHit.getBlockPos();
            
            // 获取挖掘进度
            currentData.mineProgress = getBlockBreakingProgress(mc, pos);
            
            tickCounter++;
            if (!pos.equals(lastPos) || tickCounter % UPDATE_INTERVAL == 0) {
                lastPos = pos.immutable();
                BlockState state = mc.level.getBlockState(pos);
                Block block = state.getBlock();
                BlockEntity blockEntity = mc.level.getBlockEntity(pos);
                collectBlockInfo(currentData, state, block, blockEntity, pos);
            }
        } else {
            currentData.clear();
            lastPos = BlockPos.ZERO;
        }
    }
    
    private static void collectBlockInfo(BlockInfoData data, BlockState state, Block block, BlockEntity blockEntity, BlockPos pos) {
        data.clear();
        
        data.blockName = block.getName().getString();
        data.modId = state.getBlock().builtInRegistryHolder().key().location().getNamespace();
        data.isVanilla = data.modId.equals("minecraft");
        data.blockPos = pos;
        
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            data.canMine = mc.player.hasCorrectToolForDrops(state);
        }
        
        detectPlant(data, state);
        
        if (blockEntity instanceof AbstractFurnaceBlockEntity) {
            data.isFurnace = true;
            ClientFurnaceCache.FurnaceData cacheData = ClientFurnaceCache.getData(pos);
            if (cacheData != null) {
                data.furnaceBurnTime = cacheData.burnTime;
                data.furnaceTotalBurnTime = cacheData.burnTotal;
                data.furnaceCookTime = cacheData.cookTime;
                data.furnaceTotalCookTime = cacheData.cookTotal;
                data.inputItemName = getCachedItemName(cacheData.inputName);
                data.inputItemCount = cacheData.inputCount;
                data.fuelItemName = getCachedItemName(cacheData.fuelName);
                data.fuelItemCount = cacheData.fuelCount;
                data.outputItemName = getCachedItemName(cacheData.outputName);
                data.outputItemCount = cacheData.outputCount;
            }
        }
        
        if (blockEntity instanceof BaseContainerBlockEntity && !(blockEntity instanceof AbstractFurnaceBlockEntity)) {
            data.isContainer = true;
            ClientContainerCache.ContainerData cacheData = ClientContainerCache.getData(pos);
            if (cacheData != null && cacheData.itemNames != null && !cacheData.itemNames.isEmpty()) {
                List<String> items = new java.util.ArrayList<>();
                for (int i = 0; i < cacheData.itemNames.size(); i++) {
                    String itemId = cacheData.itemNames.get(i);
                    int count = cacheData.itemCounts.get(i);
                    String displayName = getCachedItemName(itemId);
                    items.add(displayName + " x" + count);
                }
                data.containerItems = items;
            } else if (blockEntity instanceof BaseContainerBlockEntity container) {
                data.containerItems = collectContainerItems(container);
            }
        }
    }
    
    private static String getCachedItemName(String itemId) {
        if (itemId == null || itemId.isEmpty()) {
            return "";
        }
        return itemNameCache.computeIfAbsent(itemId, BlockInfoTracker::getItemNameFromId);
    }
    
    private static void detectPlant(BlockInfoData data, BlockState state) {
        for (var property : state.getProperties()) {
            if (property instanceof IntegerProperty intProp) {
                String name = intProp.getName();
                if (name.equals("age") || name.equals("stage") || name.equals("growth") || name.equals("level") || name.equals("height")) {
                    data.isPlant = true;
                    Integer value = state.getValue(intProp);
                    int actualMax = intProp.getPossibleValues().stream().mapToInt(Integer::intValue).max().orElse(7);
                    if (actualMax > 0) {
                        data.plantGrowth = (float) value / actualMax;
                    }
                    return;
                }
            }
        }
    }
    
    private static List<String> collectContainerItems(BaseContainerBlockEntity container) {
        Map<String, Integer> itemCounts = new HashMap<>();
        for (int i = 0; i < container.getContainerSize(); i++) {
            var stack = container.getItem(i);
            if (!stack.isEmpty()) {
                String name = stack.getDisplayName().getString();
                itemCounts.put(name, itemCounts.getOrDefault(name, 0) + stack.getCount());
            }
        }
        return itemCounts.entrySet().stream()
            .map(e -> e.getKey() + " x" + e.getValue())
            .collect(java.util.stream.Collectors.toList());
    }
    
    public static BlockInfoData getCurrentData() {
        return currentData;
    }
    
    private static String getItemNameFromId(String itemId) {
        if (itemId == null || itemId.isEmpty()) {
            return "";
        }
        try {
            net.minecraft.resources.ResourceLocation loc = net.minecraft.resources.ResourceLocation.parse(itemId);
            var optItem = net.minecraft.core.registries.BuiltInRegistries.ITEM.get(loc);
            if (optItem.isPresent()) {
                net.minecraft.world.item.Item item = optItem.get().value();
                return item.getDefaultInstance().getDisplayName().getString();
            }
        } catch (Exception e) {
            // 静默处理异常
        }
        return itemId;
    }
    
    private static float getBlockBreakingProgress(Minecraft mc, BlockPos pos) {
        if (mc.level == null || mc.player == null) {
            return 0f;
        }
        try {
            Class<?> clazz = mc.level.getClass();
            java.lang.reflect.Method getDestroyProgressMethod = null;
            for (java.lang.reflect.Method method : clazz.getDeclaredMethods()) {
                if (method.getName().contains("DestroyProgress") && method.getParameterTypes().length == 2) {
                    Class<?>[] paramTypes = method.getParameterTypes();
                    if ((paramTypes[0] == int.class || paramTypes[0] == Integer.class) && paramTypes[1] == BlockPos.class) {
                        if (method.getReturnType() == int.class || method.getReturnType() == Integer.class) {
                            getDestroyProgressMethod = method;
                            break;
                        }
                    }
                }
            }
            
            if (getDestroyProgressMethod != null) {
                getDestroyProgressMethod.setAccessible(true);
                int progress = (int) getDestroyProgressMethod.invoke(mc.level, mc.player.getId(), pos);
                if (progress >= 0 && progress <= 10) {
                    return (float) progress / 10.0f;
                }
            }
            
            Field[] fields = clazz.getDeclaredFields();
            for (Field f : fields) {
                if (f.getType().getName().contains("Int2ObjectMap")) {
                    f.setAccessible(true);
                    Object progressMap = f.get(mc.level);
                    if (progressMap instanceof Int2ObjectMap) {
                        Int2ObjectMap<?> map = (Int2ObjectMap<?>) progressMap;
                        int playerId = mc.player.getId();
                        Object progressObj = map.get(playerId);
                        if (progressObj != null) {
                            Class<?> progressClass = progressObj.getClass();
                            Field posField = null;
                            Field progressField = null;
                            for (Field pf : progressClass.getDeclaredFields()) {
                                if (pf.getType() == BlockPos.class) {
                                    posField = pf;
                                } else if (pf.getType() == int.class) {
                                    progressField = pf;
                                }
                            }
                            if (posField != null && progressField != null) {
                                posField.setAccessible(true);
                                progressField.setAccessible(true);
                                BlockPos progressPos = (BlockPos) posField.get(progressObj);
                                if (progressPos != null && progressPos.equals(pos)) {
                                    int progressValue = progressField.getInt(progressObj);
                                    if (progressValue >= 0 && progressValue <= 10) {
                                        return (float) progressValue / 10.0f;
                                    } else if (progressValue >= 0 && progressValue <= 9) {
                                        return (float) progressValue / 9.0f;
                                    }
                                }
                            }
                        }
                    }
                    break;
                }
            }
        } catch (Exception e) {
            // 静默处理反射异常
        }
        return 0f;
    }
}

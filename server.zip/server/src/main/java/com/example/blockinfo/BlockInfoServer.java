package com.example.blockinfo;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.network.PacketDistributor;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.minecraft.world.item.ItemStack;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

@Mod(BlockInfoServer.MOD_ID)
public class BlockInfoServer {
    public static final String MOD_ID = "blockinfo";
    public static final Logger LOGGER = LogUtils.getLogger();
    
    public BlockInfoServer(IEventBus modEventBus) {
        modEventBus.addListener(this::registerPayloadHandlers);
        NeoForge.EVENT_BUS.register(new ServerEventHandler());
    }
    
    private void registerPayloadHandlers(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(
            FurnaceDataPacket.TYPE,
            FurnaceDataPacket.STREAM_CODEC,
            FurnaceDataPacket::handle
        );
        registrar.playToClient(
            ContainerDataPacket.TYPE,
            ContainerDataPacket.STREAM_CODEC,
            ContainerDataPacket::handle
        );
    }
    
    public static class FurnaceDataPacket implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<FurnaceDataPacket> TYPE = 
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(MOD_ID, "furnace_data"));
        
        public static final StreamCodec<FriendlyByteBuf, FurnaceDataPacket> STREAM_CODEC = StreamCodec.of(
            (buf, packet) -> {
                buf.writeBlockPos(packet.pos);
                buf.writeInt(packet.cookTime);
                buf.writeInt(packet.cookTotal);
                buf.writeInt(packet.burnTime);
                buf.writeInt(packet.burnTotal);
                buf.writeInt(packet.inputCount);
                buf.writeUtf(packet.inputName);
                buf.writeInt(packet.fuelCount);
                buf.writeUtf(packet.fuelName);
                buf.writeInt(packet.outputCount);
                buf.writeUtf(packet.outputName);
            },
            (buf) -> new FurnaceDataPacket(
                buf.readBlockPos(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readUtf(),
                buf.readInt(),
                buf.readUtf(),
                buf.readInt(),
                buf.readUtf()
            )
        );
        
        public final BlockPos pos;
        public final int cookTime;
        public final int cookTotal;
        public final int burnTime;
        public final int burnTotal;
        public final int inputCount;
        public final String inputName;
        public final int fuelCount;
        public final String fuelName;
        public final int outputCount;
        public final String outputName;
        
        public FurnaceDataPacket(BlockPos pos, int cookTime, int cookTotal, int burnTime, int burnTotal,
                                  int inputCount, String inputName, int fuelCount, String fuelName,
                                  int outputCount, String outputName) {
            this.pos = pos;
            this.cookTime = cookTime;
            this.cookTotal = cookTotal;
            this.burnTime = burnTime;
            this.burnTotal = burnTotal;
            this.inputCount = inputCount;
            this.inputName = inputName;
            this.fuelCount = fuelCount;
            this.fuelName = fuelName;
            this.outputCount = outputCount;
            this.outputName = outputName;
        }
        
        @Override
        public CustomPacketPayload.Type<FurnaceDataPacket> type() {
            return TYPE;
        }
        
        public void handle(net.neoforged.neoforge.network.handling.IPayloadContext context) {
        }
    }
    
    public static class ContainerDataPacket implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<ContainerDataPacket> TYPE = 
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(MOD_ID, "container_data"));
        
        public static final StreamCodec<FriendlyByteBuf, ContainerDataPacket> STREAM_CODEC = StreamCodec.of(
            (buf, packet) -> {
                buf.writeBlockPos(packet.pos);
                buf.writeInt(packet.itemNames.size());
                for (int i = 0; i < packet.itemNames.size(); i++) {
                    buf.writeUtf(packet.itemNames.get(i));
                    buf.writeInt(packet.itemCounts.get(i));
                }
            },
            (buf) -> {
                BlockPos pos = buf.readBlockPos();
                int count = buf.readInt();
                List<String> itemNames = new ArrayList<>();
                List<Integer> itemCounts = new ArrayList<>();
                for (int i = 0; i < count; i++) {
                    itemNames.add(buf.readUtf());
                    itemCounts.add(buf.readInt());
                }
                return new ContainerDataPacket(pos, itemNames, itemCounts);
            }
        );
        
        public final BlockPos pos;
        public final List<String> itemNames;
        public final List<Integer> itemCounts;
        
        public ContainerDataPacket(BlockPos pos, List<String> itemNames, List<Integer> itemCounts) {
            this.pos = pos;
            this.itemNames = itemNames;
            this.itemCounts = itemCounts;
        }
        
        @Override
        public CustomPacketPayload.Type<ContainerDataPacket> type() {
            return TYPE;
        }
        
        public void handle(net.neoforged.neoforge.network.handling.IPayloadContext context) {
        }
    }
    
    public static class ServerEventHandler {
        private final Map<ServerPlayer, BlockPos> lastFurnacePos = new HashMap<>();
        private int tickCounter = 0;
        private static final int SYNC_INTERVAL = 5;
        
        private static java.lang.reflect.Field cookingTimerField;
        private static java.lang.reflect.Field cookingTotalTimeField;
        private static java.lang.reflect.Field litTimeRemainingField;
        private static java.lang.reflect.Field litTotalTimeField;
        
        static {
            try {
                cookingTimerField = AbstractFurnaceBlockEntity.class.getDeclaredField("cookingTimer");
                cookingTimerField.setAccessible(true);
            } catch (Exception e) {}
            
            try {
                cookingTotalTimeField = AbstractFurnaceBlockEntity.class.getDeclaredField("cookingTotalTime");
                cookingTotalTimeField.setAccessible(true);
            } catch (Exception e) {}
            
            try {
                litTimeRemainingField = AbstractFurnaceBlockEntity.class.getDeclaredField("litTimeRemaining");
                litTimeRemainingField.setAccessible(true);
            } catch (Exception e) {}
            
            try {
                litTotalTimeField = AbstractFurnaceBlockEntity.class.getDeclaredField("litTotalTime");
                litTotalTimeField.setAccessible(true);
            } catch (Exception e) {}
        }
        
        private final Map<ServerPlayer, BlockPos> lastContainerPos = new HashMap<>();
        
        @SubscribeEvent
        public void onServerTick(ServerTickEvent.Post event) {
            tickCounter++;
            if (tickCounter % SYNC_INTERVAL != 0) return;
            
            for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
                ServerLevel level = player.serverLevel();
                if (level == null) continue;
                
                HitResult hitResult = player.pick(5.0D, 0.0F, false);
                if (hitResult instanceof BlockHitResult blockHit) {
                    BlockPos pos = blockHit.getBlockPos();
                    BlockEntity blockEntity = level.getBlockEntity(pos);
                    if (blockEntity instanceof AbstractFurnaceBlockEntity furnace) {
                        syncFurnaceData(player, furnace, pos);
                    } else if (blockEntity instanceof BaseContainerBlockEntity container) {
                        syncContainerData(player, container, pos);
                    }
                }
            }
        }
        
        private void syncFurnaceData(ServerPlayer player, AbstractFurnaceBlockEntity furnace, BlockPos pos) {
            try {
                int cookTime = 0, cookTotal = 200, burnTime = 0, burnTotal = 200;
                
                try {
                    if (cookingTimerField != null) cookTime = cookingTimerField.getInt(furnace);
                } catch (Exception e) {}
                
                try {
                    if (cookingTotalTimeField != null) cookTotal = cookingTotalTimeField.getInt(furnace);
                } catch (Exception e) {}
                
                try {
                    if (litTimeRemainingField != null) burnTime = litTimeRemainingField.getInt(furnace);
                } catch (Exception e) {}
                
                try {
                    if (litTotalTimeField != null) burnTotal = litTotalTimeField.getInt(furnace);
                } catch (Exception e) {}
                
                if (cookTotal <= 0) cookTotal = 200;
                if (burnTotal <= 0) burnTotal = 200;
                
                ItemStack input = furnace.getItem(0);
                ItemStack fuel = furnace.getItem(1);
                ItemStack output = furnace.getItem(2);
                
                String inputId = input.isEmpty() ? "" : input.getItem().builtInRegistryHolder().key().location().toString();
                String fuelId = fuel.isEmpty() ? "" : fuel.getItem().builtInRegistryHolder().key().location().toString();
                String outputId = output.isEmpty() ? "" : output.getItem().builtInRegistryHolder().key().location().toString();
                
                FurnaceDataPacket packet = new FurnaceDataPacket(
                    pos, cookTime, cookTotal, burnTime, burnTotal,
                    input.getCount(), inputId,
                    fuel.getCount(), fuelId,
                    output.getCount(), outputId
                );
                PacketDistributor.sendToPlayer(player, packet);
            } catch (Exception e) {
                LOGGER.error("同步熔炉数据失败: " + e.getMessage());
            }
        }
        
        private void syncContainerData(ServerPlayer player, BaseContainerBlockEntity container, BlockPos pos) {
            try {
                Map<String, Integer> itemMap = new HashMap<>();
                
                for (int i = 0; i < container.getContainerSize(); i++) {
                    ItemStack stack = container.getItem(i);
                    if (!stack.isEmpty()) {
                        String itemId = stack.getItem().builtInRegistryHolder().key().location().toString();
                        itemMap.put(itemId, itemMap.getOrDefault(itemId, 0) + stack.getCount());
                    }
                }
                
                List<String> itemNames = new ArrayList<>();
                List<Integer> itemCounts = new ArrayList<>();
                
                for (Map.Entry<String, Integer> entry : itemMap.entrySet()) {
                    itemNames.add(entry.getKey());
                    itemCounts.add(entry.getValue());
                }
                
                ContainerDataPacket packet = new ContainerDataPacket(pos, itemNames, itemCounts);
                PacketDistributor.sendToPlayer(player, packet);
                
                lastContainerPos.put(player, pos);
            } catch (Exception e) {
                LOGGER.error("同步容器数据失败: " + e.getMessage());
            }
        }
    }
}